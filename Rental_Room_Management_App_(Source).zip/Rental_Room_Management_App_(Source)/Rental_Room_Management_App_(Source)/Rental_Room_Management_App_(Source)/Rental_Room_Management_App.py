from login import SplashScreen
import tkinter as tk

'''==================TRANG CHỦ=================='''
if __name__ == "__main__":
    root = tk.Tk()
    SplashScreen(root)
    root.mainloop()
